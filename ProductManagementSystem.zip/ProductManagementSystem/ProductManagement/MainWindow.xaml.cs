﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace ProductManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       static string conString = ConfigurationManager.ConnectionStrings["conString"].ConnectionString;
        SqlConnection connection = new SqlConnection(conString);
        SqlCommand cmd;
        int noOfRecord = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = int.Parse(productId.Text);
                string name = productName.Text;
                int price = int.Parse(productPrice.Text);
                int quantity = int.Parse(productPrice.Text);
                string query = "insert into Products_dsingh58 values(" + id + ",'" + name + "'," + price + "," + quantity + ")";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int status = cmd.ExecuteNonQuery();
                if (status > 0)
                {
                    MessageBox.Show("Record Added Successfully!!");
                    ClearData();

                }
                else
                {
                    MessageBox.Show("Issue in adding the record");
                }
            }
            catch(SqlException EX)
            {
                MessageBox.Show("Exception occured!!!"+EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if(connection.State==ConnectionState.Open)
                connection.Close();
            }
            
            CountAllrecord();
            Display();

        }
        public void Display()
        {

            try
            {
               
                string query = "select * from Products_dsingh58";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                productDetails.DataContext = table;
            
              
            }
            catch (SqlException EX)
            {
                MessageBox.Show("Exception occured!!!" + EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }

        }
        public void CountAllrecord()
        {
            try
            {

                string query = "select count(id) from Products_dsingh58";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                connection.Open();
                noOfRecord =(int)(cmd.ExecuteScalar());
                count.Text = Convert.ToString(noOfRecord);
               
            }
            catch (SqlException EX)
            {
                MessageBox.Show("Exception occured!!!" + EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        public void ClearData()
        {
            productId.Text = "";
            productName.Text = "";
            productPrice.Text = "";
            productQuantity.Text = "";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            CountAllrecord();
            Display();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {

                string query = "select * from Products_dsingh58 where id="+int.Parse(search.Text)+"";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    productId.Text = reader[0].ToString();
                    productName.Text = reader[1].ToString();
                    productPrice.Text = reader[2].ToString();
                    productQuantity.Text = reader[3].ToString();
                }


            }
            catch (SqlException EX)
            {
                MessageBox.Show("Exception occured!!!" + EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
               int id = int.Parse(productId.Text);
                string name = productName.Text;
                int price = int.Parse(productPrice.Text);
                int quantity = int.Parse(productPrice.Text);
                string query = "UPDATE Products_dsingh58 SET  name='" + name + "', price=" + price + ",quantity=" + quantity + " where id="+id+"";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int status = cmd.ExecuteNonQuery();
                if (status > 0)
                {
                    MessageBox.Show("Record Updated Successfully!!");
                    ClearData();

                }
                else
                {
                    MessageBox.Show("Issue in adding the record");
                }
            }
            catch (SqlException EX)
            {
                MessageBox.Show("Exception occured!!!" + EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }

            CountAllrecord();
            Display();
        }
    }
}
